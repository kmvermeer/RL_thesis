function nodeMouseDownFcn(g, cb)

disp('down');
set(cb, 'Selected', 'on');